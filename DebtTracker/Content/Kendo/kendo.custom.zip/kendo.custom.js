// Kendo UI theme for data visualization widgets
// Use as theme: 'newTheme' in configuration options (or change the name)
kendo.dataviz.ui.registerTheme('newTheme', {
    "chart": {
        "title": {
            "color": "#fff"
        },
        "legend": {
            "labels": {
                "color": "#fff"
            }
        },
        "chartArea": {
            "background": "#1c1c1c"
        },
        "seriesDefaults": {
            "labels": {
                "color": "#fff"
            }
        },
        "axisDefaults": {
            "line": {
                "color": "#4d4d4d"
            },
            "labels": {
                "color": "#fff"
            },
            "minorGridLines": {
                "color": "#4d4d4d"
            },
            "majorGridLines": {
                "color": "#4d4d4d"
            },
            "title": {
                "color": "#fff"
            }
        },
        "seriesColors": [
            "#3f51b5",
            "#03a9f4",
            "#4caf50",
            "#f9ce1d",
            "#ff9800",
            "#ff5722"
        ],
        "tooltip": {}
    },
    "gauge": {
        "pointer": {
            "color": "#3f51b5"
        },
        "scale": {
            "rangePlaceholderColor": "#4d4d4d",
            "labels": {
                "color": "#fff"
            },
            "minorTicks": {
                "color": "#fff"
            },
            "majorTicks": {
                "color": "#fff"
            },
            "line": {
                "color": "#fff"
            }
        }
    }
});